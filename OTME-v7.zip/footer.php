
<footer class="full-width otm-footer">
  <div class="row">
    <div class="small-12 medium-4 large-3 columns footer-content">
      <h1>General</h1>
      <h2>+44 (0)20 3031 6000</h2>
      <p><a href="mailto:info@otmentertain.com">info@otmentertain.com</a></p>
      <div class="social">
        <img src="img/linkedin.jpg" alt="">
        <img src="img/facebook.jpg" alt="">
        <img src="img/twitter.jpg" alt="">
      </div>
    </div>
    <div class="small-6 medium-3 large-3 columns footer-content">
      <h1>London</h1>
      <h2>45-51 Whitfield St<br />
        London W1T 4HD<br />
        United Kingdom</h2>
        <p><a href="">Google Map</a></p>
      </div>
      <div class="small-6 medium-5 large-6 columns footer-content">
        <h1>Hong Kong</h1>
        <h2>7/F Cheung Wah Industrial Building<br />
          No. 10-12 Shipyard Lane Quarry Bay<br />
          Hong Kong S.A.R., China</h2>
          <p><a href="">Google Map</a></p>
        </div>
      </footer>
      <div class="bottom-bar central">
        <div class="row">
          <div class="small-12 columns">&copy; OTM 2014. Part of the Edicis Group of Companies</div>
        </div>
        <div class="row">
          <div class="small-12 columns">
            <img src="img/otm.jpg"><img src="img/otme.jpg"><img src="img/twlve.jpg"><img src="img/wlp.jpg"><img src="img/3sixty.jpg"><img src="img/verboo.jpg">
          </div>
        </div>
      </div>