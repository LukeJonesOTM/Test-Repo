<nav id="my-menu">
    <ul>
      <li><input class="search-box" type="text" name="search" placeholder="Search our blog"></input></li>
      <li><a href="index.php">Home</a></li>
      <li><a href="work.php">Work</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="blog-home.php">Blog</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
</nav>