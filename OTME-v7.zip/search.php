<div class="medium-4 medium-offset-2 columns hide-for-small"><!-- Search Box -->
	<input class="search-box" type="text" name="search" placeholder="Search our blog"></input>
</div><!-- Search Box End -->