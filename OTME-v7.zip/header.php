
  <header class="full-width top-nav mm-fixed-top">
    <div class="logo"><a href="index.html">
      <img src="img/logo.png" alt="OTM Entertain">
    </div>
    <ul class="show-for-medium-up">
      <li><a href="../contact.php">Contact</a></li>
      <li><a href="">About</a></li>
      <li><a href="../blog-home.php">Blog</a></li>
      <li><a href="../work.php">Work</a></li>
      <li><a href="../index.php">Home</a></li>
    </ul>
          <div class="mobile-menu hide-for-medium-up">
        <a class="" href="#my-menu"><img src="img/menu-btn.jpg"></a>
      </div>
  </header>